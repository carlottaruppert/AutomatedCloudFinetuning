from io import BytesIO
import sys
from time import perf_counter

from PIL import Image
import pydicom
import numpy as np
from unittest import TestCase, main
sys.path.append('../')
from b_box_utils.DicomAnalyzer import DicomAnalyzer

class AnonymizationTestCase(TestCase):
    def test_exam_id_consistent(self):
        dcm1 = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')
        dcm2 = DicomAnalyzer(dcm_path='test_dataset/dcm2.dcm')
        dcm3 = DicomAnalyzer(dcm_path='test_dataset/dcm3.dcm')
        dcm4 = DicomAnalyzer(dcm_path='test_dataset/dcm4.dcm')

        dcm1.anonymize()
        dcm2.anonymize()
        dcm3.anonymize()
        dcm4.anonymize()

        self.assertTrue(dcm1.dcm.StudyInstanceUID ==
                        dcm2.dcm.StudyInstanceUID ==
                        dcm3.dcm.StudyInstanceUID ==
                        dcm4.dcm.StudyInstanceUID)

    def test_saving_successful(self):
        dcm1 = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')
        dcm2 = DicomAnalyzer(dcm_path='test_dataset/dcm2.dcm')
        dcm3 = DicomAnalyzer(dcm_path='test_dataset/dcm3.dcm')
        dcm4 = DicomAnalyzer(dcm_path='test_dataset/dcm4.dcm')

        uid_1 = dcm1.dcm.SOPInstanceUID
        uid_2 = dcm2.dcm.SOPInstanceUID
        uid_3 = dcm3.dcm.SOPInstanceUID
        uid_4 = dcm4.dcm.SOPInstanceUID

        dcm1.anonymize()
        dcm2.anonymize()
        dcm3.anonymize()
        dcm4.anonymize()

        dcm1.save('test_outputs')
        dcm2.save('test_outputs')
        dcm3.save('test_outputs')
        dcm4.save('test_outputs')

        dcm1_loaded = DicomAnalyzer(dcm_path=f'test_outputs/{dcm1.dcm.SOPInstanceUID}.dcm')
        dcm2_loaded = DicomAnalyzer(dcm_path=f'test_outputs/{dcm2.dcm.SOPInstanceUID}.dcm')
        dcm3_loaded = DicomAnalyzer(dcm_path=f'test_outputs/{dcm3.dcm.SOPInstanceUID}.dcm')
        dcm4_loaded = DicomAnalyzer(dcm_path=f'test_outputs/{dcm4.dcm.SOPInstanceUID}.dcm')

        self.assertTrue(DicomAnalyzer.is_dicom_file(f'test_outputs/{dcm1.dcm.SOPInstanceUID}.dcm'))

        self.assertNotEqual(dcm1_loaded.dcm.SOPInstanceUID, uid_1)
        self.assertNotEqual(dcm2_loaded.dcm.SOPInstanceUID, uid_2)
        self.assertNotEqual(dcm3_loaded.dcm.SOPInstanceUID, uid_3)
        self.assertNotEqual(dcm4_loaded.dcm.SOPInstanceUID, uid_4)

    def test_tags_replaced(self):
        # Patient related
        keys_to_anonymize = ['PatientName', 'PatientBirthDate', 'PatientID',
                             'PersonAddress', 'PersonTelephoneNumbers', 'PersonTelecomInformation']
        # Institution related
        keys_to_anonymize += ['InstitutionName', 'ReferringPhysicianName', 'StationName',
                             'ManufacturerModelName', 'InstitutionName', 'OperatorsName',
                             'DeviceSerialNumber', 'PerformingPhysicianName', 'InstitutionAddress',
                             'StationName', 'RequestingService']
        # Study related
        keys_to_anonymize += ['SOPInstanceUID', 'StudyInstanceUID', 'SeriesInstanceUID',
                              'SeriesInstanceUID', 'AccessionNumber', 'StudyDate',
                              'SeriesDate', 'AcquisitionDate', 'ContentDate']
        # Other
        keys_to_anonymize += ['AdditionalPatientHistory', 'PatientComments', 'ReasonForStudy',
                              'ReasonForTheRequestedProcedure']

        dcm1 = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')

        original_values = [(tag, getattr(dcm1.dcm, tag)) for tag in keys_to_anonymize if hasattr(dcm1.dcm, tag)]

        dcm1.anonymize()

        for tag, val in original_values:
            if not val:
                continue
            self.assertNotEqual(val, getattr(dcm1.dcm, tag))

    def test_tags_unchanged(self):
        # Patient related
        keys_to_anonymize = ['PatientName', 'PatientBirthDate', 'PatientID',
                             'PersonAddress', 'PersonTelephoneNumbers', 'PersonTelecomInformation']
        # Institution related
        keys_to_anonymize += ['InstitutionName', 'ReferringPhysicianName', 'StationName',
                             'ManufacturerModelName', 'InstitutionName', 'OperatorsName',
                             'DeviceSerialNumber', 'PerformingPhysicianName', 'InstitutionAddress',
                             'StationName']
        # Study related
        keys_to_anonymize += ['SOPInstanceUID', 'StudyInstanceUID', 'SeriesInstanceUID',
                              'SeriesInstanceUID', 'AccessionNumber', 'StudyDate',
                              'SeriesDate', 'AcquisitionDate', 'ContentDate']
        # Other
        keys_to_anonymize += ['AdditionalPatientHistory', 'PatientComments', 'ReasonForStudy',
                              'ReasonForTheRequestedProcedure']

        dcm1 = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')

        original_values = [(tag, getattr(dcm1.dcm, tag)) for tag in keys_to_anonymize if hasattr(dcm1.dcm, tag)]

        for tag, val in original_values:
            self.assertEqual(val, getattr(dcm1.dcm, tag))

    def test_name_hashing(self):
        name = 'Janusz'
        h1 = DicomAnalyzer.replace_string(name, 11)
        h2 = DicomAnalyzer.replace_string(name, 11)

        self.assertEqual(len(h1), 11)
        self.assertEqual(h1, h2)

    def test_projection_missing(self):
        da = DicomAnalyzer(dcm_path='test_dataset/missing_projection_tag.dcm')
        metadata = da.get_metadata()
        self.assertIsNone(metadata.get('view_position'))

    def test_date_hashing(self):
        da1 = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')
        da2 = DicomAnalyzer(dcm_path='test_dataset/dcm2.dcm')
        print(da1.dcm.StudyDate)
        print(da2.dcm.StudyDate)
        da1.anonymize()
        da2.anonymize()
        print(da1.dcm.StudyDate)
        print(da2.dcm.StudyDate)

class MetadataTestCase(TestCase):
    dcm = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')
    # print(dcm.get_metadata())

class VolumeTestCase(TestCase):

    def test_get_volume_slice(self):
        da = DicomAnalyzer(dcm_path='test_dataset/volume.dcm')
        num_of_frames = da.getTagValue('NumberOfFrames', asString=False)
        for i in range(num_of_frames):
            t1 = perf_counter()
            img = da.get_slice(i)
            t2 = perf_counter()
            print(f'Frame {i} took {t2 - t1:.4f} seconds')
            self.assertIsInstance(img, Image.Image)

class DicomAnalyzerTestCase(TestCase):

    def test_convert(self):
        da = DicomAnalyzer(dcm_path='test_dataset/dcm1.dcm')
        pixel_spacing = da.getTagValue('ImagerPixelSpacing', convert=True)
        self.assertIsInstance(pixel_spacing, list)

    def test_pristina_preprocessing(self):
        path = 'test_dataset/pristina_lcc.dcm'
        da = DicomAnalyzer(dcm_path=path)
        img = da.get_image(False)
        img.show()

    def test_cr_preprocessing(self):
        path = 'test_dataset/bad_contrast.dcm'
        da = DicomAnalyzer(dcm_path=path)
        img = da.get_image(True)
        img.save('test_outputs/cr_output.jpeg', format='JPEG')

    def test_bad_windowing(self):
        path = 'test_dataset/bad_windowing.dcm'
        da = DicomAnalyzer(dcm_path=path)
        img = da.get_image(True, windowing_mode='softer')
        img.save('test_outputs/bad_windowing_output.jpeg', format='JPEG')

##############################################################################

def test_aws():
    # Loading a DICOM file from a bytes object
    dicom_path = 'test_dataset/test_dicom2.dcm'
    with open(dicom_path, mode='rb') as file:
        fileContent = file.read()
    da = DicomAnalyzer(dcm_bytes=fileContent)

    # Loading a DICOM file from a file path
    da = DicomAnalyzer(dcm_path=dicom_path)

    # Reading metadata
    metadata: dict = da.get_metadata()
    print(metadata)

    # Getting the image
    img: Image = da.get_image()

    # Saving the image into a buffer
    img_byte_arr = BytesIO()
    img.save(img_byte_arr, format='JPEG')
    img_byte_arr.seek(0)

    # Saving the image into a file
    img.save('test_outputs/output_img.jpeg', format='JPEG')

    # Anonimize
    da.anonymize()
    print(da.get_metadata())
    da.save('test_outputs')

#######################################################

if __name__ == '__main__':
    main()
    # test_aws()