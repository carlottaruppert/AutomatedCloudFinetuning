import unittest

from PIL import Image, ImageDraw
import numpy as np
from matplotlib import pyplot as plt

from b_box_utils import (
    PreprocessorMarginRight, 
    PreprocessorMarginSides, 
    PreprocessorFixedWidth, 
    PreprocessorResizeDistort,
    yolo11_normalization
)

import torch
import torchvision.transforms.v2 as transforms
torch_transform = transforms.Compose([
            transforms.ToImage(),
            transforms.ToDtype(torch.float32, scale=True),
            transforms.Resize(128),
            transforms.CenterCrop(384),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])


class TestPreprocessing(unittest.TestCase):

    def setUp(self):
        self.path_rmlo = "tests/test_dataset/rmlo_original.png"
        self.path_lmlo_high = "tests/test_dataset/lmlo_high_original.png"
        self.img = Image.open(self.path_rmlo)
        self.img_high = Image.open(self.path_lmlo_high)

    def tearDown(self):
        self.img.close()
        self.img_high.close()

    # Preprocessing
    def test_preprocessor_margin_right(self):
        input_shape = (640, 640)
        flip = True
        crop = None
        channels = 3
        square = True

        expected = np.load("tests/test_dataset/margin_right_input.npy")

        prep = PreprocessorMarginRight(input_shape)
        result = prep.prepare_input_data(self.img, channels, flip)

        # fig = plt.figure()
        # ax1 = fig.add_subplot(131)
        # ax1.imshow(result[0])
        # ax2 = fig.add_subplot(132)
        # ax2.imshow(expected[0])
        # ax3 = fig.add_subplot(133)
        # ax3.imshow(((result[0] - expected[0]) * 255).astype(np.uint8))
        # plt.show()

        self.assertTupleEqual(result.shape, expected.shape)
        self.assertEqual(result.shape, (1, *input_shape, channels))
        self.assertAlmostEqual(np.sum(result - expected), 0, delta=1e-6)

        # Image.fromarray((result[0]*255).astype(np.uint8)).save("tests/test_outputs/rmlo_margin_right.png")

    def test_preprocessor_margin_sides(self):
        input_shape = (640, 640)
        flip = False
        crop = None
        channels = 3
        square = True
        padding_value = 114

        expected = np.load("tests/test_dataset/margin_sides_input.npy")

        prep = PreprocessorMarginSides(input_shape, padding_value)
        result = prep.prepare_input_data(self.img, channels, flip)

        # fig = plt.figure()
        # ax1 = fig.add_subplot(131)
        # ax1.imshow(result[0])
        # ax2 = fig.add_subplot(132)
        # ax2.imshow(expected[0])
        # ax3 = fig.add_subplot(133)
        # ax3.imshow(((result[0] - expected[0])))
        # plt.show()

        # Image.fromarray((result[0]*255).astype(np.uint8)).save("tests/test_outputs/rmlo_margin_sides.png")

        self.assertTupleEqual(result.shape, expected.shape)
        self.assertEqual(result.shape, (1, *input_shape, channels))
        self.assertAlmostEqual(np.sum(result - expected), 0, delta=120)

    def test_preprocessing_fixed_width(self):
        input_shape = (384, 384)
        flip = False
        channels = 3
        padding_value = 0
        fixed_img_width = 128

        # expected = np.load("tests/test_dataset/fixed_width_input.npy")

        with Image.open(self.path_rmlo) as inputs:
          expected = torch_transform(inputs).unsqueeze(0).numpy().squeeze().transpose([1, 2, 0])

        prep = PreprocessorFixedWidth(input_shape, fixed_img_width, padding_value, yolo11_normalization)
        result = prep.prepare_input_data(self.img, channels, flip)

        # fig = plt.figure()
        # ax1 = fig.add_subplot(131)
        # ax1.imshow(result[0])
        # ax2 = fig.add_subplot(132)
        # ax2.imshow(expected)
        # ax3 = fig.add_subplot(133)
        # ax3.imshow(((result[0] - expected) * 255).astype(np.uint8))
        # plt.show()

        # Image.fromarray((result[0]*255).astype(np.uint8)).save("tests/test_outputs/rmlo_fixed_width.png")

        self.assertTupleEqual(result[0].shape, expected.shape)
        self.assertEqual(result.shape, (1, *input_shape, channels))
        self.assertAlmostEqual(np.sum(np.abs(result[0] - expected)), 0, delta=160)

    def test_preprocessing_fixed_width_thin_image(self):
        input_shape = (384, 384)
        flip = False
        channels = 3
        padding_value = 0
        fixed_img_width = 128

        # expected = np.load("tests/test_dataset/fixed_width_input.npy")

        expected = torch_transform(self.img_high).unsqueeze(0).numpy().squeeze().transpose([1, 2, 0])

        prep = PreprocessorFixedWidth(input_shape, fixed_img_width, padding_value, yolo11_normalization)
        result = prep.prepare_input_data(self.img_high, channels, flip)

        # fig = plt.figure()
        # ax1 = fig.add_subplot(131)
        # ax1.imshow(result[0])
        # ax2 = fig.add_subplot(132)
        # ax2.imshow(expected)
        # ax3 = fig.add_subplot(133)
        # ax3.imshow(((result[0] - expected) * 255).astype(np.uint8))
        # plt.show()

        self.assertTupleEqual(result[0].shape, expected.shape)
        self.assertEqual(result.shape, (1, *input_shape, channels))
        self.assertAlmostEqual(np.sum(np.abs(result[0] - expected)), 0, delta=800)

    def test_preprocessing_resize_distort(self):
        input_shape = (512, 512)
        flip = True
        channels = 3

        preprocessor = PreprocessorResizeDistort(input_shape)
        result = preprocessor.prepare_input_data(self.img, channels, flip)

        self.assertTupleEqual(result.shape, (1, *input_shape, channels))

    # Coordinates
    def test_coordinates_margin_right(self):
        original_img_size = (200, 300)
        original_img_points = [(0, 0), (1/6, 1/6), (1/3, 1/3), (1/2, 1/2), (2/3, 2/3), (5/6, 5/6), (1, 1)]
        square_img_points = [(0, 0), (1/9, 1/6), (2/9, 1/3), (1/3, 1/2), (4/9, 2/3), (5/9, 5/6), (2/3, 1)]
        prep = PreprocessorMarginRight((640, 640))
        for point_org, point_sq in zip(original_img_points, square_img_points):
            x, y = prep.transform_coordinates(point_sq, original_img_size)
            self.assertAlmostEqual(x, point_org[0])
            self.assertAlmostEqual(y, point_org[1])

    def test_preprocess_coordinates_margin_right(self):
        original_img_size = (2082, 2800)
        original_img_points = [(0, 0), (0.142347, 0.235283), (0.258219, 0.148295), (0.692742, 0.972375), (1, 1)]
        flip = True

        prep = PreprocessorMarginRight((640, 640))

        for point in original_img_points:
            new_point = prep.preprocess_coordinates(point, original_img_size, flip)
            new_point = prep.transform_coordinates(new_point, original_img_size, flip)
            self.assertTupleEqual(point, new_point)

    def test_coordinates_margin_sides(self):
        original_img_size = (2234, 3325)
        original_img_points = [(0.6325572123992838, 0.8015625), (0.2348855752014324, 0.128125), (0.6023248657117277, 0.43125), (0.5465113025962399, 0.8984375), (0.52325565129812, 0.70625), (0.8465092043419874, 0.5890625), (0.32093148500447627, 0.4), (0.6372083426589077, 0.48125), (0.39767513428827217, 0.3625), (0.3162803547448523, 0.7046875)]
        square_img_points = [(0.5890625, 0.8015625), (0.321875, 0.128125), (0.56875, 0.43125), (0.53125, 0.8984375), (0.515625, 0.70625), (0.7328125, 0.5890625), (0.3796875, 0.4), (0.5921875, 0.48125), (0.43125, 0.3625), (0.3765625, 0.7046875)]
        prep = PreprocessorMarginSides((640, 640))
        for point_org, point_sq in zip(original_img_points, square_img_points):
            x, y = prep.transform_coordinates(point_sq, original_img_size)
            self.assertAlmostEqual(x, point_org[0])
            self.assertAlmostEqual(y, point_org[1])

    def test_coordinates_fixed_width(self):
        original_img_size = (2234, 3325)
        original_img_points = [(0.046875, 0.6784680451127819), (0.9296875, 0.6574718045112781), (0.84375, 0.8201926691729322), (0.8046875, 0.5944830827067669), (0.3046875, 0.9829135338345864), (0.6015625, 0.5892340225563909), (0.0, 0.7991964285714285), (0.25, 0.40026785714285706), (0.8046875, 0.5892340225563909), (0.53125, 0.5577396616541352)]
        square_img_points = [(0.409375, 0.553125), (0.5859375, 0.546875), (0.56875, 0.5953125), (0.5609375, 0.528125), (0.4609375, 0.64375), (0.5203125, 0.5265625), (0.4, 0.5890625), (0.45, 0.4703125), (0.5609375, 0.5265625), (0.50625, 0.5171875)]
        prep = PreprocessorFixedWidth((640, 640), fixed_img_width=128)
        for point_org, point_sq in zip(original_img_points, square_img_points):
            x, y = prep.transform_coordinates(point_sq, original_img_size)
            self.assertAlmostEqual(x, point_org[0])
            self.assertAlmostEqual(y, point_org[1])

    def test_coordinates_resize_distort(self):
        original_img_size = (2082, 2800)
        target_size = (512, 640)
        original_img_points = [(0, 0), (0.142347, 0.235283), (0.258219, 0.148295), (0.692742, 0.972375), (1, 1)]
        prep = PreprocessorResizeDistort(target_size)
        for pt in original_img_points:
            x, y = prep.transform_coordinates(pt, original_img_size)
            self.assertEqual(x, pt[0])
            self.assertEqual(y, pt[1])

    # Bounding boxes
    def test_box_margin_right(self):
        img_size = (2394, 3062)
        predicted_box = (0.44, 0.422, 0.11, 0.1)
        original_box_expected = (0.5627736006683375, 0.422, 0.14069340016708437, 0.1)

        prep = PreprocessorMarginRight((640, 640))
        
        original_box = prep.transform_box_coordinates(predicted_box, img_size)

        self.assertTupleEqual(original_box, original_box_expected)

    def test_preprocess_box_margin_right(self):
        img_size = (2082, 2800)
        original_box = (0.767554, 0.444444, 0.139734, 0.092475)
        flip = True

        prep = PreprocessorMarginRight((640, 640))

        new_bbox = prep.preprocess_box_coordinates(original_box, img_size, flip)
        new_bbox = prep.transform_box_coordinates(new_bbox, img_size, flip)
        
        self.assertTupleEqual(original_box, new_bbox)

    def test_box_margin_sides(self):
        img_size = (2394, 3062)
        predicted_box = (0.44, 0.422, 0.11, 0.1)
        original_box_expected = (0.42325814536340856, 0.422, 0.1406934001670844, 0.1)

        prep = PreprocessorMarginSides((640, 640))
        
        original_box = prep.transform_box_coordinates(predicted_box, img_size)

        self.assertTupleEqual(original_box, original_box_expected)

    def test_box_fixed_width(self):
        predicted_box = (0.44, 0.422, 0.11, 0.1)
        original_box_expected = (0.3500000000000001, 0.34754082299150874, 0.275, 0.19546048334421948)

        prep = PreprocessorFixedWidth((640, 640), fixed_img_width=256)

        with Image.open('tests/test_dataset/lcc_box.png') as img:
            original_box = prep.transform_box_coordinates(predicted_box, img.size)

        self.assertTupleEqual(original_box, original_box_expected)

    def test_box_resize_distort(self):
        original_img_size = (2394, 3062)
        target_size = (640, 512)
        predicted_box = (0.44, 0.422, 0.11, 0.1)

        prep = PreprocessorResizeDistort(target_size)
        original_box = prep.transform_box_coordinates(predicted_box, original_img_size)

        self.assertTupleEqual(original_box, predicted_box)

    # Overlay
    def test_overlay_margin_sides(self):
        prep = PreprocessorMarginSides((640, 640))
        with Image.open('tests/test_dataset/lcc_box.png') as original_image:
        # prep = PreprocessorFixedWidth((640, 640), 256)
            square_tensor = prep.prepare_input_data(original_image, 3)

        # Overlay on preprocessed image
        square_image = Image.fromarray((square_tensor[0]*255).astype(np.uint8)).convert('RGBA')
        alpha = 80
        square_image.putalpha(255-alpha)
        overlay = Image.new('RGBA', square_image.size, (0, 0, 0, alpha))
        draw = ImageDraw.Draw(overlay)
        x, y, r = 252, 250, 20
        draw.ellipse((x-r, y-r, x+r, y+r), fill='red')
        composite_image = Image.alpha_composite(overlay, square_image)
        composite_image.save("tests/test_outputs/lcc_overlay_predicted.png", 'PNG')

        # Overlay on original image
        original_image = original_image.convert('RGBA')
        original_image.putalpha(255-alpha)
        overlay_array = np.asarray(overlay)
        original_overlay = prep.transform_overlay(overlay_array, original_image.size)
        original_overlay_image = Image.fromarray(original_overlay).convert('RGBA').resize(original_image.size)
        composite_image = Image.alpha_composite(original_overlay_image, original_image)
        composite_image.save("tests/test_outputs/lcc_overlay_original.png", 'PNG')

    def test_overlay_resize_distort(self):
        flip = True
        preprocessor = PreprocessorResizeDistort((640, 300))
        with Image.open('tests/test_dataset/rmlo_original.png') as original_image:
            preproced_tensor = preprocessor.prepare_input_data(original_image, 3, flip=flip)
            preproced_image = Image.fromarray((preproced_tensor[0]*255).astype(np.uint8))
            alpha = 80
            preproced_image.putalpha(255-alpha)
            overlay = Image.new('RGBA', preproced_image.size, (0, 0, 0, alpha))
            draw = ImageDraw.Draw(overlay)
            x, y, r = 358, 210, 10
            draw.ellipse((x-r, y-r, x+r, y+r), fill='red')
            composite_image = Image.alpha_composite(overlay, preproced_image)
            composite_image.save("tests/test_outputs/rmlo_overlay_predicted.png", 'PNG')

            original_image = original_image.convert('RGBA')
            original_image.putalpha(255-alpha)
            overlay_array = np.asarray(overlay)
            original_overlay = preprocessor.transform_overlay(overlay_array, original_image.size, flip=flip)
            original_overlay_image = Image.fromarray(original_overlay).convert('RGBA').resize(original_image.size)
            composite_image = Image.alpha_composite(original_overlay_image, original_image)
            composite_image.save("tests/test_outputs/rmlo_overlay_original.png", 'PNG')


# Helpers
def test_box_image(preprocessor):
    predicted_box = [0.58, 0.45, 0.06, 0.05]

    img = Image.open('tests/test_dataset/lcc_box.png')
    preprocessed_image = preprocessor.prepare_input_data(img, 3, resample=Image.LANCZOS, flip=True)
    img_to_save = Image.fromarray((preprocessed_image[0]*255).astype(np.uint8))

    x, y, w, h = predicted_box
    x *= preprocessor.target_size[0]
    y *= preprocessor.target_size[1]
    w *= preprocessor.target_size[0]
    h *= preprocessor.target_size[1]
    draw = ImageDraw.Draw(img_to_save)
    draw.rectangle((x, y, x+w, y+h), width=1, outline='white')
    img_to_save.save("tests/test_outputs/lcc_box_predicted.png")

    original_box = preprocessor.transform_box_coordinates(predicted_box, img.size, flip=True)

    print(predicted_box)
    print(original_box)
    
    x, y, w, h = original_box
    x *= img.size[0]
    y *= img.size[1]
    w *= img.size[0]
    h *= img.size[1]
    draw = ImageDraw.Draw(img)
    draw.rectangle((x, y, x+w, y+h), width=3, outline='white')
    img.save("tests/test_outputs/lcc_box_original.png")

    img.close()

# def test_coordinates_image(self):
#     original_img_size = (2234, 3325)
#     square_img_size = (640, 640)
#     org_img = Image.new("L", original_img_size)

#     # mode = 'margin_sides'
#     mode = 'fixed_width'

#     # Generate random points
#     if mode == 'margin_sides':
#         r = square_img_size[0] / original_img_size[0]
#         dx = int((original_img_size[1] - original_img_size[0]) * r) // 2
#         dy = 0
#     else:
#         r = 128 / original_img_size[0]
#         dx = int(square_img_size[0] - 128) // 2
#         dy = int(square_img_size[1] - original_img_size[1] * r) // 2
#     points_squared = [(random.randint(dx, square_img_size[0] - dx - 1),
#                        random.randint(dy, square_img_size[1] - dy - 1))
#                       for _ in range(10)]

#     # Prepare input data
#     if mode == 'margin_sides':
#         preprocessor = PreprocessorMarginSides(square_img_size, flip=False)
#     else:
#         preprocessor = PreprocessorFixedWidth(square_img_size, flip=False, fixed_img_width=128, padding_value=100)
#     square_input = preprocessor.prepare_input_data(org_img, channels=3)

#     # Draw points on the squared image
#     square_image = Image.fromarray((square_input[0]*255).astype(np.uint8))
#     draw = ImageDraw.Draw(square_image)
#     for x, y in points_squared:
#         draw.ellipse([x - 3, y - 3, x + 3, y + 3], fill='white')

#     # Transform points back to the original image
#     square_points_normalized = [(point[0] / square_img_size[0], point[1] / square_img_size[1]) for point in points_squared]
#     print(square_points_normalized)
#     original_points = [preprocessor.transform_coordinates(point, original_img_size) for point in square_points_normalized]
#     print(original_points)
#     # Draw points on the original image
#     draw = ImageDraw.Draw(org_img)
#     for x, y in original_points:
#         x *= original_img_size[0]
#         y *= original_img_size[1]
#         draw.ellipse([x - 7, y - 7, x + 7, y + 7], fill='white')

#     square_image.save(f"tests/test_outputs/points_{mode}_square.png")
#     org_img.save(f"tests/test_outputs/points_{mode}_org.png")




if __name__ == '__main__':
    unittest.main()
    # test_box_image(PreprocessorResizeDistort((640, 512)))