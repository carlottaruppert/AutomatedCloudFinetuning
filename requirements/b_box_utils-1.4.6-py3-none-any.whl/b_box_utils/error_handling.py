import traceback
import logging
from os.path import join, isdir
from os import getenv, mkdir

def set_logger(main_folder):
    LOG_FORMAT = '%(asctime)s %(message)s'
    LOG_NAME_ERR = 'bbox_error'
    LOG_NAME_WARN = 'bbox_warning'
    BASE_FOLDER = join(main_folder, 'log_files')
    LOG_FILE_ERR = join(BASE_FOLDER, 'logfile_error.log')
    LOG_FILE_WARN = join(BASE_FOLDER, 'logfile_warning.log')

    if not isdir(BASE_FOLDER):
        mkdir(BASE_FOLDER)

    log_formatter = logging.Formatter(LOG_FORMAT)

    # Errors
    log_err = logging.getLogger(LOG_NAME_ERR)
    file_handler_error = logging.FileHandler(LOG_FILE_ERR, mode='a')
    file_handler_error.setFormatter(log_formatter)
    log_err.addHandler(file_handler_error)
    log_err.setLevel(logging.ERROR)

    # Warnings
    log_warn = logging.getLogger(LOG_NAME_WARN)
    file_handler_warning = logging.FileHandler(LOG_FILE_WARN, mode='a')
    file_handler_warning.setFormatter(log_formatter)
    log_warn.addHandler(file_handler_warning)
    log_warn.setLevel(logging.WARNING)

def format_error_message(*args, **kwargs):
    msg = traceback.format_exc()
    msg = " ".join(msg.split())
    final_msg = "Exception:\n"
    final_msg += msg+'\n'
    logging.error(final_msg)
    if getenv("MOD")=='DEVELOPMENT':
        print(final_msg)
    return final_msg
