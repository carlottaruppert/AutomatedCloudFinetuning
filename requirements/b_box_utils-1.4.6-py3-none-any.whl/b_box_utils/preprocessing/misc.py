from numpy import ndarray, float32


def resnet18_normalization(input_tensor: ndarray) -> ndarray:
    assert input_tensor.ndim == 4
    assert input_tensor.dtype == float32

    new_tensor = input_tensor.copy()
    new_tensor[0, ..., 0] = (new_tensor[0, ..., 0] - 0.485) / 0.229
    new_tensor[0, ..., 1] = (new_tensor[0, ..., 1] - 0.456) / 0.224
    new_tensor[0, ..., 2] = (new_tensor[0, ..., 2] - 0.406) / 0.225
    # new_tensor = np.roll(new_tensor, shift=-1, axis=-3)

    return new_tensor