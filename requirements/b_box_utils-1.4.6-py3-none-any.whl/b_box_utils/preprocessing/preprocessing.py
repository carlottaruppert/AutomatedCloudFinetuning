from typing import Tuple, Union, Callable
from abc import ABC, abstractmethod

import numpy as np

from PIL import Image, ImageOps


TYPE_SIZE = Tuple[int, int]
TYPE_POINT = Tuple[float, float]
TYPE_BOX = Tuple[float, float, float, float]
TYPE_CROP = Union[Tuple[float, float, float, float], None]


class Preprocessor(ABC):
    """
    Abstract class for preprocessing images.
    """
    def __init__(self, target_size: TYPE_SIZE, extra_step: Callable=None):
        self.target_size = target_size
        self.extra_step = extra_step

    def prepare_input_data(self, image: Image, channels: int=1, flip: bool=False, crop: TYPE_CROP=None, **kwargs) -> np.ndarray:
        """
        Prepares the input data for the model. The image is resized and preprocessed.
        :param image: numpy array, the image to preprocess
        :param channels: int, the number of channels of the image
        :param crop: tuple of four floats, the crop coordinates (left, top, right, bottom)
        :return: numpy array, the preprocessed image
        """
        image = image.convert("L")

        if flip:
            image = image.transpose(Image.FLIP_LEFT_RIGHT)

        if crop:
            # left, top, right, bottom
            scaled_crop = (int(crop[0] * image.shape[1]),
                           int(crop[1] * image.shape[0]),
                           int(crop[2] * image.shape[1]),
                           int(crop[3] * image.shape[0]))
            image = image.crop(scaled_crop)

        image = self._preprocess_image(image, **kwargs)

        array = np.asarray(image, dtype=np.float32)
        array = np.ascontiguousarray(array)
        array /= 255.0

        target_shape = (self.target_size[1], self.target_size[0])
        array = array.reshape((*target_shape, 1))
        array = np.broadcast_to(array, (1, *target_shape, channels))

        if self.extra_step is not None:
            array = self.extra_step(array)

        return array

    @abstractmethod
    def transform_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Transforms the coordinates from the preprocessed image to the original image.
        :param point: tuple of two floats, the coordinates in the preprocessed image (x, y).
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: tuple of two floats, the coordinates in the original image
        """
        ...

    @abstractmethod
    def transform_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_BOX:
        """
        Transforms the coordinates of a bounding box from the preprocessed image to the original image.
        :param box: The coordinates of the bounding box in the preprocessed image (x1, y1, w, h)
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: tuple of two tuples of two floats, the coordinates of the bounding box in the original image
        """
        ...

    @abstractmethod
    def transform_overlay(self, overlay: np.ndarray, original_img_size: TYPE_SIZE, flip: bool=False) -> np.ndarray:
        """
        Transforms the overlay from the preprocessed image to the original image.
        :param overlay: numpy array, the overlay image
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: numpy array, the transformed overlay image
        """
        ...

    @abstractmethod
    def _preprocess_image(self, image: Image, **kwargs) -> Image:
        ...


class PreprocessorMarginRight(Preprocessor):

    def transform_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Postprocessing: Transforms the x coordinate from the new image size to the original image size.
        :param x: float, the x coordinate in the input image
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: float, the x coordinate in the original image
        """
        assert 0 <= point[0] <= 1, "The x coordinate must be in the range [0, 1]"
        new_x = point[0] * original_img_size[1] / original_img_size[0]
        if flip:
            new_x = 1 - new_x
        return (new_x, point[1])
    
    def preprocess_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Preprocessing: Transforms the x coordinate from the original image size to the new image size.
        :param x: float, the x coordinate in the original image
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: float, the x coordinate in the new image
        """
        assert 0 <= point[0] <= 1, "The x coordinate must be in the range [0, 1]"
        if flip:
            new_x = 1 - point[0]
        else:
            new_x = point[0]
        new_x = new_x * original_img_size[0] / original_img_size[1]
        return (new_x, point[1])

    def transform_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_BOX:
        """
        Postprocessing: convert predictions to original image size
        """
        x, y, w, h = box
        new_x = x * original_img_size[1] / original_img_size[0]
        new_w = w * original_img_size[1] / original_img_size[0]
        if flip:
            new_x = 1 - new_x - new_w
        return (new_x, y, new_w, h)
    
    def preprocess_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False, x_position: str='left') -> TYPE_BOX:
        """
        Preprocessing: convert annotations from original to new image size to prepare for training
        x_position: position of the x coordinates relative to the box. Options: 'left' or 'center'
        """
        x, y, w, h = box
        if flip:
            x = 1 - x
        if x_position == 'left':
            x = x - w
        new_x = x * original_img_size[0] / original_img_size[1]
        new_w = w * original_img_size[0] / original_img_size[1]
        return (new_x, y, new_w, h)

    def transform_overlay(self, overlay: np.ndarray, original_img_size: TYPE_SIZE, flip: bool=False) -> np.ndarray:
        """
        Postprocessing: convert predictions to original image size
        """
        r = original_img_size[0] / original_img_size[1]
        x_right = int(overlay.shape[1] * r)
        overlay = overlay[:, :x_right]
        if flip:
            overlay = np.fliplr(overlay)
        return overlay

    def _preprocess_image(self, image: Image, **kwargs) -> Image:
        """
        Reshapes the image to a square by adding black borders.
        The image is pasted on the top left corner of a new square image.
        :param img: numpy array
        :return: numpy array, the squared image
        """
        long_dim = np.max(image.size)
        new_im = Image.new("L", (long_dim, long_dim))
        new_im.paste(image, (0, 0))
        new_im = new_im.resize(self.target_size)
        return new_im


class PreprocessorMarginSides(Preprocessor):

    def  __init__(self, target_size: TYPE_SIZE, padding_value: int=114, extra_step: Callable=None):
        super().__init__(target_size, extra_step)
        self.padding_value = padding_value

    def transform_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Transforms the coordinates from the preprocessed image to the original image.
        :param point: Tuple of normalized (x, y) coordinates in the preprocessed image.
        :param original_img_size: Tuple of (width, height) of the original image.
        :return: Transformed (x, y) coordinates in the original image.
        """
        r = self.target_size[1] / original_img_size[1]
        dx = (self.target_size[0] - original_img_size[0] * r) / 2
        new_x = (point[0] * self.target_size[0] - dx) / (original_img_size[0] * r)
        if flip:
            new_x = 1 - new_x
        return new_x, point[1]

    def transform_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_BOX:
        x, y, w, h = box
        r = min(self.target_size[0] / original_img_size[0], self.target_size[1] / original_img_size[1])
        dx = (self.target_size[0] - original_img_size[0] * r) / 2
        new_x = (x * self.target_size[0] - dx) / (original_img_size[0] * r)
        new_w = w * self.target_size[0] / (original_img_size[0] * r)
        if flip:
            new_x = 1 - new_x - new_w
        return new_x, y, new_w, h

    def transform_overlay(self, overlay: np.ndarray, original_img_size: TYPE_SIZE, flip: bool=False) -> np.ndarray:
        y, x = overlay.shape[:2]
        r = y / original_img_size[1]
        dx = (x - original_img_size[0] * r) / 2
        overlay = overlay[:, int(dx):int(dx + original_img_size[0] * r)]
        if flip:
            overlay = np.fliplr(overlay)
        return overlay

    def _preprocess_image(self, image: Image, **kwargs) -> Image:
        """
        Resizes the image to fit into a new shape and adds black padding on the sides.
        The height is resized to the target height and the width is padded.
        :param img: numpy array
        :return: numpy array, the resized image
        """

        # Compute padding
        r = min(self.target_size[0] / image.size[0], self.target_size[1] / image.size[1])
        new_unpad_size = int(round(image.size[0] * r)), int(round(image.size[1] * r))

        # Resize the image
        image = image.resize(new_unpad_size)

        # Find padding
        dw = self.target_size[1] - new_unpad_size[0]
        dh = self.target_size[0] - new_unpad_size[1]
        dw /= 2
        dh /= 2
        top = int(round(dh - 0.1))
        bottom = int(round(dh + 0.1))
        left = int(round(dw - 0.1))
        right = int(round(dw + 0.1))

        # Adding border
        image = ImageOps.expand(image,
                                border=(left, top, right, bottom),
                                fill=self.padding_value)
        return image


class PreprocessorFixedWidth(Preprocessor):

    def __init__(self, target_size: TYPE_SIZE, fixed_img_width: int=0, padding_value: int=0, extra_step: Callable=None):
        super().__init__(target_size, extra_step)
        if fixed_img_width <= 0:
            raise ValueError("The fixed_img_width must be a positive integer")
        self.fixed_img_width = fixed_img_width
        self.padding_value = padding_value

    def transform_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Transforms coordinates from the preprocessed image back to the original image.
        :param point: Tuple of normalized (x, y) coordinates in the preprocessed image.
        :param original_img_size: Tuple of (width, height) of the original image.
        :return: Transformed (x, y) coordinates in the original image.
        """
        r = self.fixed_img_width / original_img_size[0]

        dx = (self.target_size[0] - self.fixed_img_width) / 2
        dy = (self.target_size[1] - original_img_size[1] * r) / 2

        # Scale the point back to original size but keep it normalized
        new_x = (point[0] * self.target_size[0] - dx) / self.fixed_img_width
        new_y = (point[1] * self.target_size[1] - dy) / (original_img_size[1] * r)

        # Reverse the flip transformation if needed
        if flip:
            new_x = 1 - x

        return new_x, new_y

    def transform_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_BOX:
        x, y, w, h = box
        r = self.fixed_img_width / original_img_size[0]

        dx = (self.target_size[0] - self.fixed_img_width) / 2
        dy = (self.target_size[1] - original_img_size[1] * r) / 2

        # Scale the box back to original size but keep it normalized
        new_x = (x * self.target_size[0] - dx) / self.fixed_img_width
        new_y = (y * self.target_size[1] - dy) / (original_img_size[1] * r)
        new_w = w * self.target_size[0] / self.fixed_img_width
        new_h = h * self.target_size[1] / (original_img_size[1] * r)

        # Reverse the flip transformation if needed
        if flip:
            new_x = 1 - new_x - new_w

        return new_x, new_y, new_w, new_h

    def transform_overlay(self, overlay: np.ndarray, original_img_size: TYPE_SIZE, flip: bool=False) -> np.ndarray: # todo
        r = self.fixed_img_width / original_img_size[0]
        dx = (self.target_size[0] - self.fixed_img_width) / 2
        dy = (self.target_size[1] - original_img_size[1] * r) / 2
        overlay = overlay[int(dy):int(dy + original_img_size[1] * r), int(dx):int(dx + self.fixed_img_width)]
        if flip:
            overlay = np.fliplr(overlay)
        return overlay

    def _preprocess_image(self, image: Image, **kwargs) -> Image:
        """
        Resizes the image to fit into a new shape and adds black padding
        around the image. The image is resized to have a fixed width and
        the height padded or cropped to keep the aspect ratio.
        :param img: numpy array
        :return: numpy array, the resized image
        """
        r = self.fixed_img_width / image.size[0]

        # Crop the image if too high
        if r * image.size[1] > self.target_size[1]:
            cropped_y = int(self.target_size[1] / r)
            crop_top = int((image.size[1] - cropped_y) / 2)
            image = image.crop((0, crop_top, image.size[0], crop_top + cropped_y))
            r = self.fixed_img_width / image.size[0]

        new_unpad_size = int(round(image.size[0] * r)), int(round(image.size[1] * r))

        # Resize the image
        image = image.resize(new_unpad_size, Image.BILINEAR)

        # Find padding
        dw = self.target_size[0] - new_unpad_size[0]
        dh = self.target_size[1] - new_unpad_size[1]
        dw /= 2
        dh /= 2
        top = int(round(dh - 0.1))
        bottom = int(round(dh + 0.1))
        left = int(round(dw - 0.1))
        right = int(round(dw + 0.1))

        # Adding border
        image = ImageOps.expand(image,
                                border=(left, top, right, bottom),
                                fill=self.padding_value)
        return image


class PreprocessorResizeDistort(Preprocessor):

    def transform_coordinates(self, point: TYPE_POINT, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_POINT:
        """
        Transforms the coordinates from the preprocessed image to the original image.
        :param point: tuple of two floats, the coordinates in the preprocessed image (x, y).
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: tuple of two floats, the coordinates in the original image
        """
        x, y = point
        if flip:
            x = 1 - x
        return x, y

    def transform_box_coordinates(self, box: TYPE_BOX, original_img_size: TYPE_SIZE, flip: bool=False) -> TYPE_BOX:
        """
        Transforms the coordinates of a bounding box from the preprocessed image to the original image.
        :param box: The coordinates of the bounding box in the preprocessed image (x1, y1, w, h)
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: tuple of two tuples of two floats, the coordinates of the bounding box in the original image
        """
        x, y, w, h = box
        if flip:
            x = 1 - x - w
        return x, y, w, h

    def transform_overlay(self, overlay: np.ndarray, original_img_size: TYPE_SIZE, flip: bool=False) -> np.ndarray:
        """
        Transforms the overlay from the preprocessed image to the original image.
        :param overlay: numpy array, the overlay image
        :param original_img_size: tuple of two integers, the size of the original image (width, height)
        :param flip: boolean, whether the image was flipped
        :return: numpy array, the transformed overlay image
        """
        overlay_img = Image.fromarray(overlay)
        overlay_img = overlay_img.resize(original_img_size, Image.BILINEAR)
        overlay = np.asarray(overlay_img)
        if flip:
            overlay = np.fliplr(overlay)
        return overlay

    def _preprocess_image(self, image: Image, **kwargs) -> Image:
        """
        Resizes the image to fit into a new shape by simply resizing without keeping the aspect ratio.
        :param img: numpy array
        :return: numpy array, the resized image
        """
        resample = kwargs.get('resample')
        return image.resize(self.target_size, resample)