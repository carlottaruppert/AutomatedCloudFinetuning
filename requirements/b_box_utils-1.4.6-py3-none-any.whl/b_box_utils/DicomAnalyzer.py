import pydicom
from enum import Enum, auto
from pydicom.pixels import convert_color_space
import numpy as np
from PIL import Image
from typing import cast
from io import BytesIO
from hashlib import sha256
from os.path import join
from datetime import datetime, timedelta
import random
from string import ascii_lowercase
from typing import Union

pydicom.config.IGNORE=0


class ImageFormat(Enum):
    JPEG = auto()
    PNG = auto()


class DicomAnalyzer:
    '''
    Auxiliary class for handling DICOM files.
    '''

    def __init__(self, dcm_bytes=None, dcm_path=None, load_pixel_array=True):
        '''
        Constructor

        :param dcm_bytes: The DICOM file to be handled
        :type dcm_bytes: Byte like object
        :param dcm_path: A path to the DICOM file
        :type dcm_path: str
        '''
        self.dcm = None
        assert bool(dcm_bytes) != bool(dcm_path), 'Only one of the following should be passed: dcm_bytes or dcm_path'
        if dcm_path is not None:
            with open(dcm_path, 'rb') as f:
                dcm_bytes = f.read()

        dcm_file = BytesIO(dcm_bytes)
        self.dcm = pydicom.dcmread(dcm_file, stop_before_pixels=(not load_pixel_array))
        num_of_frames = self.getTagValue('NumberOfFrames', default=1, asString=False)
        self.is_3d = int(num_of_frames) > 1


############################## PUBLIC METHODS ##############################

    def getTagValue(self, tag_name, default=None, asString=True, convert=False):
        '''
        Returns the value of a given tag.

        :param tag_name: The given tag name
        :type tag_name: str
        :param default: Value returned if the tag is not found
        :type default: str
        :param asString: If True, the result is casted of string
        :type asString: boolean
        '''
        if tag_name in self.dcm or isinstance(tag_name, tuple):
            result = self.dcm.get(tag_name, default)
        else:
            result = self._deep_search(tag_name)

        if not result:
            result = default
        elif convert:
            result = self.convert(result)
        elif asString:
            result = str(result)

        return result

    def get_image(self, normalize=False, windowing_mode=None) -> Image:
        '''
        Returns a PIL image
        '''
        pixel_array = self._process_pixel_array(self.dcm.pixel_array, windowing_mode=windowing_mode)
        if pixel_array is None:
            return None

        pixel_array =  self.to_8_bit(pixel_array, normalize)

        # convert to image
        img = Image.fromarray(pixel_array)

        return img

    def get_slice(self, index: int, normalize=False) -> Image:
        '''
        Returns a slice of the 3D image.,

        :param index: Index of the slice
        :type index: int
        :param normalize: If True, the image is normalized
        :type normalize: bool
        '''
        pixel_array = self.get_slice_array(index)
            
        pixel_array = self.to_8_bit(pixel_array, normalize)
        img = Image.fromarray(pixel_array)
        return img

    def get_slice_array(self, index: int, windowing_mode: str='') -> np.ndarray:
        assert self.is_3d, 'The DICOM file is not a 3D volume'
        if index < 0 or index >= self.dcm.NumberOfFrames:
            raise ValueError('Index out of range')

        pixel_array = self.dcm.pixel_array
        if pixel_array is None:
            return None

        if pixel_array.ndim != 3:
            raise ValueError('The pixel array is not 3D')

        pixel_array = pixel_array[index, :, :]
        pixel_array = self._process_pixel_array(pixel_array, windowing_mode=windowing_mode)
        
        return pixel_array

    def get_image_bytes(self, format: ImageFormat, normalize=False) -> Union[bytes, None]:
        img: Union[Image, None] = self.get_image(normalize)
        buffer: BytesIO = BytesIO()
        img.save(buffer, format=format)
        return buffer.getvalue()

    def anonymize(self):
        if self.dcm is None:
            print('DICOM not loaded correctly')
            return

        # Check if already anonymized
        if hasattr(self.dcm, 'ImageComments'):
            value = getattr(self.dcm, 'ImageComments')
            if not value:
                pass
            elif value == 'Anonymized':
                print("Already anonymized")
                return

        # Patient related
        keys_to_anonymize = ['PatientName', 'PatientBirthDate', 'PatientID',
                             'PersonAddress', 'PersonTelephoneNumbers', 'PersonTelecomInformation']
        # Institution related
        keys_to_anonymize += ['InstitutionName', 'ReferringPhysicianName', 'StationName',
                             'ManufacturerModelName', 'InstitutionName', 'OperatorsName',
                             'DeviceSerialNumber', 'PerformingPhysicianName', 'InstitutionAddress',
                             'StationName', 'RequestingService']
        # Study related
        keys_to_anonymize += ['SOPInstanceUID', 'StudyInstanceUID', 'SeriesInstanceUID',
                              'SeriesInstanceUID', 'AccessionNumber', 'StudyDate',
                              'SeriesDate', 'AcquisitionDate', 'ContentDate']
        # Other
        keys_to_anonymize += ['AdditionalPatientHistory', 'PatientComments', 'ReasonForStudy',
                              'ReasonForTheRequestedProcedure']

        try:
            for key in keys_to_anonymize:
                if not hasattr(self.dcm, key):
                    continue

                vr = self.dcm[key].VR
                value = getattr(self.dcm, key)

                if not value:
                    continue

                if vr == 'DA':
                    seed = self.getTagValue('StudyDate', asString=False)
                    try:
                        seed = int(seed) % 1234
                    except ValueError:
                        seed = 101
                    new_value = self.replace_date(value, seed=seed)
                elif vr in {'LO', 'PN', 'ST', 'LT'}:
                    new_value = self.replace_string(value, 32)
                elif vr == 'SH':
                    new_value = self.replace_string(value, 8)
                elif vr == 'UI':
                    new_value = self.replace_uid(value)
                else:
                    continue

                setattr(self.dcm, key, new_value)

            print('Anonymization succeed')
        except Exception as err:
            print('Anonymization failed')
            print(err)

    def save(self, save_folder):
        try:
            save_path = join(save_folder, self.dcm.SOPInstanceUID + '.dcm')
            self.dcm.save_as(save_path)
        except Exception as err:
            print('Saving DICOM file failed failed')
            print(err)

    def get_modality(self):
        """
        Extracts and formats the examination modality.
        """
        std = self.getTagValue(
            'StudyDescription', 'unavailable')
        sed = self.getTagValue(
            'SeriesDescription', 'unavailable')
        it = self.getTagValue('ImageType', 'unavailable')
        pn = self.getTagValue('ProtocolName', 'unavailable')

        is_tomo = "recon" in std.lower() or "recon" in sed.lower() or "tomo" in sed.lower() \
            or "tomo" in std.lower() or "tomo" in it.lower() or "tomo" in pn.lower()

        is_conv = "konv" in std.lower() or "konv" in sed.lower() or \
            "konv" in it.lower() or "konv" in pn.lower()

        is_tomo = is_tomo and not is_conv

        if is_tomo:
            return 'tomosynthesis'
        else:
            return 'mammography'

    def get_view_position(self):
        """
        Returns the view position: RCC, LCC, RMLO or LMLO
        """
        RCC = "RCC"
        LCC = "LCC"
        RMLO = "RMLO"
        LMLO = "LMLO"
        try:
            _, top_bottom = self.getTagValue(
                'PatientOrientation', ['none', 'none'], asString=False)
            series_description = self.getTagValue('SeriesDescription', '').replace(' ', '')

            if top_bottom:
                if top_bottom.lower() == 'l':
                    return RCC
                elif top_bottom.lower() == 'r':
                    return LCC
                elif top_bottom.lower() == 'fl':
                    return RMLO
                elif top_bottom.lower() == 'fr':
                    return LMLO
            if series_description:
                if 'rcc' in series_description.lower():
                    return RCC
                elif 'lcc' in series_description.lower():
                    return LCC
                elif 'rmlo' in series_description.lower():
                    return RMLO
                elif 'lmlo' in series_description.lower():
                    return LMLO

            laterality = self.getTagValue('ImageLaterality', '')
            if not laterality:
                laterality = self.getTagValue('FrameLaterality', '')
            if not laterality:
                return None
            laterality = laterality.strip()

            projection = self.getTagValue('ViewPosition', '').strip()
            if not projection:
                view_pos_seq = self.getTagValue('ViewCodeSequence', asString=False)
                if type(view_pos_seq).__name__ == 'Sequence' and len(view_pos_seq) > 0:
                    item = view_pos_seq[0]
                    if 'CodeMeaning' in item:
                        if item.CodeMeaning == 'cranio-caudal':
                            projection = 'cc'
                        elif item.CodeMeaning == 'medio-lateral oblique':
                            projection = 'mlo'
            if not projection:
                return None

            projection = laterality.lower() + projection.lower()

            if projection == 'rcc':
                return RCC
            elif projection == 'lcc':
                return LCC
            elif projection == 'rmlo':
                return RMLO
            elif projection == 'lmlo':
                return LMLO

            return None

        except Exception as err:
            print(err)

    def is_screening(self):
        """
        Returns True if the examination belonged to the screening program
        or False otherwise.
        """
        study_description = self.getTagValue(
            'StudyDescription', 'unavailable')
        series_description = self.getTagValue(
            'SeriesDescription', 'unavailable')
        return "screening" in study_description.lower() or "screening" in series_description.lower()

    def get_metadata(self) -> Union[dict, None]:
        if self.dcm:
            return self.dictify(self.dcm,
                                ignored=['PixelData',
                                         'VOILUTSequence'],
                                ignore_private=True)
        return None

############################## PRIVATE METHODS ##############################

    def _deep_search(self, search_key):
        '''
        Iteratively searches the value of a given key
        in nested DICOM tags.

        :param search_key: Tag name for the searched value
        :type search_key: str
        '''
        search_key = search_key.lower()
        for elem in self.dcm.iterall():
            current_key = elem.name
            current_key = current_key.replace(' ', '')
            current_key = current_key.replace('-', '')
            current_key = current_key.replace("'s", '')
            current_key = current_key.replace('(', '')
            current_key = current_key.replace(')', '')
            current_key = current_key.replace('&', '')
            current_key = current_key.lower()
            if search_key == current_key:
                return elem.value
        return None

    def _get_study_date(self):
        """
        Extracts and formats the study date and time.
        """
        date = self.getTagValue('StudyDate', '10000101')
        if date < '10000101':
            date = '10000101'
        date = date.ljust(8, '0')
        date = f'{date[:4]}-{date[4:6]}-{date[6:8]}'
        return date

    def _get_study_time(self):
        time = self.getTagValue('StudyTime', '000000')
        time = time.ljust(6, '0')
        time = f'{time[:2]}:{time[2:4]}:{time[4:6]}'
        return time

    def _get_referring_doctor(self):
        """
        Extracts and formats the referring physician.
        """
        referring_physician = self.getTagValue(
            'RequestingService', 'Unknown')
        if referring_physician == "Unknown":
            referring_physician = self.getTagValue(
                'ReferringPhysicianName', 'Unknown')
        referring_physician = referring_physician.replace('^', '')
        return referring_physician

    def _get_image_size(self):
        """
        Returns the physical dimensions of the FOV.
        """
        spacing = self.getTagValue(
            'PixelSpacing', 'unavailable', asString=False)

        if spacing == 'unavailable':
            spacing = self.getTagValue(
                'ImagerPixelSpacing', 'unavailable', asString=False)

        if spacing == 'unavailable':
            return [None, None]
        else:
            rows = self.getTagValue('Rows', '0')
            cols = self.getTagValue('Columns', '0')
            x = int(cols) * spacing[0]
            y = int(rows) * spacing[1]
            return x, y

    def _get_image_date(self):
        image_date = self.getTagValue('ContentDate', asString=False, default=None)
        if image_date:
            return image_date
        image_date = self.getTagValue('ImageDate', asString=False, default=None)
        if image_date:
            return image_date
        return None

    def _get_image_time(self):
        image_time = self.getTagValue('ContentTime', asString=False, default=None)
        if image_time:
            return image_time
        image_time = self.getTagValue('ImageTime', asString=False, default=None)
        if image_time:
            return image_time
        return None

    def _get_decimal_string(self, tag_name):
        value = self.getTagValue(tag_name)
        if value is None:
            return None
        try:
            value = float(value)
        except ValueError:
            print(f'Incorrect {tag_name} value: {value}')
            return None
        return value

    def _get_integer_string(self, tag_name):
        value = self.getTagValue(tag_name)
        if value is None:
            return None
        try:
            value = int(value)
        except ValueError:
            print(f'Incorrect {tag_name} value: {value}')
            return None
        return value

    def _process_pixel_array(self, pixel_array: np.ndarray, windowing_mode: str='') -> np.ndarray:      
        # Handle signed pixel values
        if getattr(self.dcm, "PixelRepresentation", 0) == 1 and getattr(self.dcm, "BitsAllocated", 0) == 8:
            pixel_array = pixel_array.view(np.uint8)

        if windowing_mode:
            pixel_array = self._apply_windowing(pixel_array, mode=windowing_mode)

        # Apply rescale slope/intercept
        slope = getattr(self.dcm, "RescaleSlope", None)
        intercept = getattr(self.dcm, "RescaleIntercept", None)
        if slope is not None and intercept is not None:
            pixel_array = pixel_array * slope + intercept
            
        # Apply VOI LUT
        pixel_array = pydicom.pixels.apply_voi_lut(pixel_array, self.dcm)
            
        # Handle photometric interpretation / inversion
        photometric = self.getTagValue("PhotometricInterpretation", asString=True)
        lut_shape = self.getTagValue("PresentationLUTShape", asString=True)
        is_monochrome1 = photometric and photometric.strip().upper() == "MONOCHROME1"
        is_inverse_lut = lut_shape and "inverse" in lut_shape.lower()

        if is_monochrome1 or is_inverse_lut:
            max_val = pixel_array.max()
            pixel_array = max_val - pixel_array

        # Flip horizontally if requested
        fov_flip = self.getTagValue("FieldOfViewHorizontalFlip", asString=True)
        if fov_flip and str(fov_flip).strip().lower() == "yes":
            pixel_array = np.fliplr(pixel_array)

        # Convert YBR -> RGB
        if photometric and "ybr" in photometric.lower():
            pixel_array = convert_color_space(pixel_array, "YBR_FULL", "RGB", per_frame=True)

        return pixel_array

    def _apply_windowing(self, pixel_array: np.ndarray, mode='softer') -> np.ndarray:
        window_center = self.getTagValue("WindowCenter", None, asString=False)
        window_width = self.getTagValue("WindowWidth", None, asString=False)
        window_presets = self.getTagValue("WindowCenterWidthExplanation", None, asString=False)

        if window_center is not None and window_width is not None:
            if isinstance(window_presets, pydicom.multival.MultiValue):
                window_presets = [str(preset).lower() for preset in window_presets]
                preset = window_presets.index(mode) if mode in window_presets else 0
            else:
                preset = 0

            if isinstance(window_center, pydicom.multival.MultiValue):
                window_center = float(window_center[preset])
            if isinstance(window_width, pydicom.multival.MultiValue):
                window_width = float(window_width[preset])

            print(f'Applying windowing: center={window_center}, width={window_width}')

            if isinstance(window_center, pydicom.multival.MultiValue):
                window_center = float(window_center[0])
            if isinstance(window_width, pydicom.multival.MultiValue):
                window_width = float(window_width[0])
            
            pixel_array = np.clip(pixel_array, window_center - window_width/2, window_center + window_width/2)
            pixel_array = ((pixel_array - (window_center - window_width/2)) / window_width * 255).astype(np.uint8)

        return pixel_array

############################### STATIC METHODS ###############################

    @staticmethod
    def to_8_bit(pixel_array: np.ndarray, normalize=False) -> np.ndarray:
        range = pixel_array.max() - pixel_array.min()
        if range == 0:
            return np.zeros_like(pixel_array).astype(np.uint8)

        if normalize:
            pixel_array = (pixel_array - pixel_array.min()) / range
        else:
            pixel_array = pixel_array.astype(np.float64) / pixel_array.max()

        pixel_array *= 255.0

        return pixel_array.astype(np.uint8)

    @staticmethod
    def determine_if_left(image):
        '''
        Determines if a given image presents the left breast.

        :param image: Input image
        :type image: PIL object
        '''
        pixel_array = np.array(image)
        if np.sum(pixel_array[:, 0], axis=0) < np.sum(pixel_array[:, -1], axis=0):
            return False
        return True

    @staticmethod
    def replace_string(string_value, length=24):
        sha = sha256(string_value.encode('utf-8'))
        digest = sha.digest()
        base62_digest = DicomAnalyzer.base62_encode(digest)
        return base62_digest[:length]

    @staticmethod
    def replace_date(date_value, shift_range=100, seed=None):
        try:
            if seed is not None:
                random.seed(seed)
            day_shift = random.randint(-shift_range, shift_range)
            if len(date_value) > 8:
                date_obj = datetime.strptime(date_value, '%Y-%m-%d %H:%M:%S')
            else:
                date_obj = datetime.strptime(date_value, '%Y%m%d')
            date_obj = date_obj + timedelta(days=day_shift)
            return date_obj.strftime('%Y%m%d')
        except Exception as err:
            print(f'Date anonymization failed: {str(err)}')
            return date_value

    @staticmethod
    def replace_uid(value):
        uid_section = value.split('.')
        new_uid_sections = []
        for section in uid_section:
            sha = sha256(section.encode('utf-8'))
            digest = sha.hexdigest()
            int_digest = int(digest, 16) % 10 ** len(section)
            new_uid_sections.append(str(int_digest))
        new_uid = '.'.join(new_uid_sections)
        if len(new_uid) > 64:
            new_uid = new_uid[:64]
        return new_uid

    @staticmethod
    def format_name(name):
        """
        Formats patient name.

        :param name: Name to be formated
        :type name: str
        """
        name = str(name)
        name = name.replace('^', ' ')
        name = name.replace('"', '_')
        name = name.replace("'", '_')
        name = name.replace('/', '')
        name = name.replace('\0', '')
        name = name.strip()
        name = name.title()
        return name

    @staticmethod
    def get_random_string(n=6):
        return ''.join(random.sample(ascii_lowercase, n))

    @staticmethod
    def base62_encode(data):
        # Convert the binary data to an integer
        BASE62_ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        num = int.from_bytes(data, 'big')
        if num == 0:
            return BASE62_ALPHABET[0]

        # Encode the integer to base62
        encoded = []
        base = len(BASE62_ALPHABET)
        while num:
            num, rem = divmod(num, base)
            encoded.append(BASE62_ALPHABET[rem])
        return ''.join(reversed(encoded))

    @staticmethod
    def is_dicom_file(path):
        try:
            return pydicom.misc.is_dicom(path)
        except:
            return False

    @staticmethod
    def dictify(ds: pydicom.Dataset, ignored=None, ignore_private=True) -> dict:
        """Turn a pydicom Dataset into a dict with keys derived from the Element tags.

        Parameters
        ----------
        ds : pydicom.dataset.Dataset
            The Dataset to dictify

        Returns
        -------
        output : dict
        """
        if ignored:
            ignored = set(ignored)
        output = dict()
        for elem in ds:
            name = pydicom.datadict.keyword_for_tag(elem.tag)
            if (not name or
                ignored and name in ignored or
                ignore_private and elem.private_creator is not None):
                continue
            if elem.VR != 'SQ':
                output[name] = DicomAnalyzer.convert(elem.value)
            else:
                output[name] = [DicomAnalyzer.dictify(item) for item in elem]
        return output

    @staticmethod
    def convert(value):
        if isinstance(value, pydicom.multival.MultiValue):
            return list(value)
        if isinstance(value, pydicom.uid.UID):
            return str(value)
        if (isinstance(value, pydicom.valuerep.DA) or
            isinstance(value, pydicom.valuerep.DT) or
            isinstance(value, pydicom.valuerep.TM) or
            isinstance(value, pydicom.valuerep.PersonName)):
            return repr(value)
        if (isinstance(value, pydicom.valuerep.DSfloat) or
            isinstance(value, pydicom.valuerep.ISfloat)):
            return float(value)
        if (isinstance(value, pydicom.valuerep.IS) or
            isinstance(value, pydicom.valuerep.DSdecimal)):
            return int(value)
        return value

################################################################################

if __name__ == '__main__':
    da = DicomAnalyzer(dcm_path='tests/test_dataset/MAMMOGRAM, Diagnosis-MG-1.2.840.113619.6.95.31.0.3.4.1.24.13.44570482-049.dcm')
    da.anonymize()
    da.save('tests/outputs')